﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static frmPrincipal.formInicio;

namespace frmPrincipal
{
    public partial class formCliente : Form
    {
        int atual = 0, cad = 0;
        formInicio.Cliente[] cliente;
        char cadastro;

        public int getCad()
        {
            return cad;
        }

        private void Habilita()
        {
            txtNome.Enabled = true;
            txtBairro.Enabled = true;
            txtCep.Enabled = true;
            txtCidade.Enabled = true;
            txtCpf.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtEstado.Enabled = true;
            txtRg.Enabled = true;
            txtTelefone.Enabled = true;

            btnAnterior.Enabled = false;
            btnProximo.Enabled = false;
            btnNovo.Enabled = false;
            btnAltera.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            btnPesquisar.Enabled = false;
            btnImprimir.Enabled = false;
            btnSair.Enabled = false;
        }

        private void Desabilita()
        {
            txtNome.Enabled = false;
            txtBairro.Enabled = false;
            txtCep.Enabled = false;
            txtCidade.Enabled = false;
            txtCpf.Enabled = false;
            txtEmail.Enabled = false;
            txtEndereco.Enabled = false;
            txtEstado.Enabled = false;
            txtRg.Enabled = false;
            txtTelefone.Enabled = false;

            btnAnterior.Enabled = true;
            btnProximo.Enabled = true;
            btnNovo.Enabled = true;
            btnAltera.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
            btnPesquisar.Enabled = true;
            btnImprimir.Enabled = true;
            btnSair.Enabled = true;
        }

        public void RecebeClientes(formInicio.Cliente[] clientes, int cadCliente)
        {
            cliente = clientes;
            cad = cadCliente;
        }

        private void Mostra()
        {
            txtCodigo.Text = cliente[atual].codigo.ToString();
            txtNome.Text = cliente[atual].nomecl;
            txtBairro.Text = cliente[atual].bairro;
            txtCep.Text = cliente[atual].cep;
            txtCidade.Text = cliente[atual].cidade;
            txtCpf.Text = cliente[atual].cpf;
            txtEmail.Text = cliente[atual].email;
            txtEndereco.Text = cliente[atual].endereco;
            txtEstado.Text = cliente[atual].estado;
            txtRg.Text = cliente[atual].rg;
            txtTelefone.Text = cliente[atual].telefone;

        }

        public formCliente()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (cad < 100)
            {
                Habilita();
                cadastro = 'N';
                txtCodigo.Text = (cad + 1).ToString();
                txtNome.Text = "";
                txtBairro.Text = "";
                txtCep.Text = "";
                txtCidade.Text = "";
                txtCpf.Text = "";
                txtEmail.Text = "";
                txtEndereco.Text = "";
                txtEstado.Text = "";
                txtRg.Text = "";
                txtTelefone.Text = "";
            }
            else
            {
                MessageBox.Show("Banco de dados cheio!!!");
            }
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (atual > 0)
            {
                atual--;
                Mostra();
            }
        }

      

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilita();
            if (cadastro == 'N')
            {
                cliente[cad].codigo = int.Parse(txtCodigo.Text);
                cliente[cad].nomecl = txtNome.Text;
                cliente[cad].bairro = txtBairro.Text;
                cliente[cad].cep = txtCep.Text;
                cliente[cad].cidade = txtCidade.Text;
                cliente[cad].cpf = txtCpf.Text;
                cliente[cad].email = txtEmail.Text;
                cliente[cad].endereco = txtEndereco.Text;
                cliente[cad].estado = txtEstado.Text;
                cliente[cad].rg = txtRg.Text;
                cliente[cad].telefone = txtTelefone.Text;


                atual = cad;
                cad++;
            }
            else
            {
                cliente[atual].nomecl = txtNome.Text;
                cliente[atual].bairro = txtBairro.Text;
                cliente[atual].cep = txtCep.Text;
                cliente[atual].cidade = txtCidade.Text;
                cliente[atual].cpf = txtCpf.Text;
                cliente[atual].email = txtEmail.Text;
                cliente[atual].endereco = txtEndereco.Text;
                cliente[atual].estado = txtEstado.Text;
                cliente[atual].rg = txtRg.Text;
                cliente[atual].telefone = txtTelefone.Text;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            cliente[atual].nomecl = "";
            cliente[atual].bairro = "";
            cliente[atual].cep = "";
            cliente[atual].cidade = "";
            cliente[atual].cpf = "";
            cliente[atual].email = "";
            cliente[atual].endereco = "";
            cliente[atual].estado = "";
            cliente[atual].rg = "";
            cliente[atual].telefone = "";
            Mostra();
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (atual < cad - 1)
            {
                atual++;
                Mostra();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnAltera_Click(object sender, EventArgs e)
        {
            Habilita();
            cadastro = 'a';
        }

        private void BtnPesquisaPesquisa_Click(object sender, EventArgs e)
        {
            if (txtPesquisa.Text != "")
            {
                int x;
                for (x = 0; x < cad; x++)
                {
                    if (cliente[x].nomecl.Contains(txtPesquisa.Text))
                    {
                        break;
                    }
                }
                if (x < cad)
                {
                    atual = x;
                    Mostra();
                }
                else
                {
                    MessageBox.Show("Nome não encontrado!!!");
                }
            }
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void BtnSairPesquisa_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = true;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados;
            Graphics objImpressao = e.Graphics;

            strDados = "FICHA DE CLIENTE" + (char)10 + (char)10;
            strDados = strDados + "Código" + " " + txtCodigo.Text + (char)10 + (char)10;
            strDados = strDados + "Nome" + " " + txtNome.Text + (char)10 + (char)10;
            strDados = strDados + "Endereço" + " " + txtEndereco.Text + (char)10 + (char)10;
            strDados = strDados + "Bairro" + " " + txtBairro.Text + (char)10 + (char)10;
            strDados = strDados + "Cidade" + " " + txtCidade.Text + (char)10 + (char)10;
            strDados = strDados + "Estado" + " " + txtEstado.Text + (char)10 + (char)10;
            strDados = strDados + "CEP" + " " + txtCep.Text + (char)10 + (char)10;
            strDados = strDados + "Telefone" + " " + txtTelefone.Text + (char)10 + (char)10;
            strDados = strDados + "E-Mail" + " " + txtEmail.Text + (char)10 + (char)10;
            strDados = strDados + "CPF" + " " + txtCpf.Text + (char)10 + (char)10;
            strDados = strDados + "RG" + " " + txtRg.Text;

            objImpressao.DrawString(strDados, new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 50, 50);
        }

        private void BtnImprimir_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void btnImprimir_Click_1(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void txtCpf_TextChanged(object sender, EventArgs e)
        {

        }

        private void formCliente_Load(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }
    }
}
