﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static frmPrincipal.formInicio;

namespace frmPrincipal
{
    public partial class formInicio : Form
    {
        public struct Usuario
        {
            public int codigo;
            public string nome, login, senha;
        }

        static public Usuario[] usuario = new Usuario[100];
        static public int cadUsuario = 0;

        public struct Fornecedor
        {
            public int codigo;
            public string nomeFantasia, razaoSocial, endereco, bairro, cidade, cep, telefone, contato, email, cnpj, inscrEstadual, estado;
        }

        static public Fornecedor[] fornecedor = new Fornecedor[100];
        static public int cadFornecedor = 0;

        public struct Cliente
        {
            public int codigo;
            public string nomecl, endereco, bairro, cidade, estado, cep, telefone, email, cpf, rg;
        }

        static public Cliente[] cliente = new Cliente[100];
        static public int cadCliente = 0;


        public formInicio()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            timer1.Start();
            int x = this.Width;
            lblMensagem.Width = x - 250;
            lblMensagem.Text = "Mensagem: Menu principal";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
      
        }

        private void usuáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formUsuario fu = new formUsuario();
            fu.RecebeUsuarios(usuario, cadUsuario);
            fu.ShowDialog();
            cadUsuario = fu.getCad();
        }

        private void FrmPrincipal_Resize(object sender, EventArgs e)
        {
            int x = this.Width;
            lblMensagem.Width = x - 250;
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formCliente cl = new formCliente();
            cl.RecebeClientes(cliente, cadCliente);
            cl.ShowDialog();
            cadCliente = cl.getCad();
        }

        private void fornecedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formFornecedor fo = new formFornecedor();
            fo.RecebeFornecedores(fornecedor, cadFornecedor);
            fo.ShowDialog();
            cadFornecedor = fo.getCad();
        }

        private void StatusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Timer1_Tick_1(object sender, EventArgs e)
        {
            lblData.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss");
        }

        private void usuáriosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ppdUsuario.ShowDialog();
        }

        private void pdUsuario_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados = "";
            Graphics objImpressao = e.Graphics;
            int pag = 1, pos = 0, linha;
            bool cabecalho = true, itens;

            while (cabecalho)
            {
                strDados = "ETEC ADOLPHO BEREZIN" + (char)10;
                strDados += ("Relatório de Usuários").PadRight(73) + "Pág: " + pag.ToString("00") + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                strDados += "Código Nome                                               Login" + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                linha = 5;
                pag++;
                itens = true;

                while (itens)
                {
                    strDados += usuario[pos].codigo.ToString("000000") + " " + usuario[pos].nome.PadRight(50) + " " + usuario[pos].login + (char)10;
                    pos++;
                    linha++;
                    if (linha >= 63)
                    {
                        itens = false;
                    }
                    if (pos >= cadUsuario)
                    {
                        itens = false;
                        cabecalho = false;
                    }
                }
                strDados += (char)12;
            }
            objImpressao.DrawString(strDados, new Font("Courier New", 10, FontStyle.Regular), Brushes.Black, 50, 50);
        }

        private void clienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ppdCliente.ShowDialog();
        }

        private void pdCliente_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados = "";
            Graphics objImpressao = e.Graphics;
            int pag = 1, pos = 0, linha;
            bool cabecalho = true, itens;

            while (cabecalho)
            {
                strDados = "ETEC ADOLPHO BEREZIN" + (char)10;
                strDados += ("Relatório de Clientes").PadRight(73) + "Pág: " + pag.ToString("00") + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                strDados += "Código Nome                                     RG              CPF" + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                linha = 5;
                pag++;
                itens = true;

                while (itens)
                {
                    strDados += cliente[pos].codigo.ToString("000000") + " " + cliente[pos].nomecl.PadRight(40) + " " + cliente[pos].rg.PadRight(15) + " " + cliente[pos].cpf + (char)10;
                    pos++;
                    linha++;
                    if (linha >= 63)
                    {
                        itens = false;
                    }
                    if (pos >= cadUsuario)
                    {
                        itens = false;
                        cabecalho = false;
                    }
                }
                strDados += (char)12;
            }
            objImpressao.DrawString(strDados, new Font("Courier New", 10, FontStyle.Regular), Brushes.Black, 50, 50);
        }

        private void pdFornecedor_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados = "";
            Graphics objImpressao = e.Graphics;
            int pag = 1, pos = 0, linha;
            bool cabecalho = true, itens;

            while (cabecalho)
            {
                strDados = "ETEC ADOLPHO BEREZIN" + (char)10;
                strDados += ("Relatório de Fornecedor").PadRight(73) + "Pág: " + pag.ToString("00") + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                strDados += "Código Nome Fantasia                Inscr. Estadual           CNPJ" + (char)10;
                strDados += "--------------------------------------------------------------------------------" + (char)10;
                linha = 5;
                pag++;
                itens = true;

                while (itens)
                {
                    strDados += fornecedor[pos].codigo.ToString("000000") + " " + fornecedor[pos].nomeFantasia.PadRight(28) + " " + fornecedor[pos].inscrEstadual.PadRight(25) + " " + fornecedor[pos].cnpj + (char)10;
                    pos++;
                    linha++;
                    if (linha >= 63)
                    {
                        itens = false;
                    }
                    if (pos >= cadUsuario)
                    {
                        itens = false;
                        cabecalho = false;
                    }
                }
                strDados += (char)12;
            }
            objImpressao.DrawString(strDados, new Font("Courier New", 10, FontStyle.Regular), Brushes.Black, 50, 50);
        }

        private void forncedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ppdFornecedor.ShowDialog();
        }

        private void relatóriosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
