﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static frmPrincipal.formInicio;

namespace frmPrincipal
{
    public partial class formFornecedor : Form
    {
        int atual = 0, cad = 0;
        formInicio.Fornecedor[] fornecedor;
        char cadastro;

        public int getCad()
        {
            return cad;
        }

        private void Habilita()
        {
            txtNomeFantasia.Enabled = true;
            txtBairro.Enabled = true;
            txtCep.Enabled = true;  
            txtCidade.Enabled = true;   
            txtCnpj.Enabled = true; 
            txtContato.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtEstado.Enabled = true;
            txtInscr.Enabled = true;
            txtRazao.Enabled = true;
            txtTelefone.Enabled = true;
           
            btnAnterior.Enabled = false;
            btnProximo.Enabled = false;
            btnNovo.Enabled = false;

            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            btnPesquisar.Enabled = false;
            btnImprimir.Enabled = false;
            btnSair.Enabled = false;
        }

        private void Desabilita()
        {
            txtNomeFantasia.Enabled = false;
            txtBairro.Enabled = false;
            txtCep.Enabled = false;
            txtCidade.Enabled = false;
            txtCnpj.Enabled = false;
            txtContato.Enabled = false;
            txtEmail.Enabled = false;
            txtEndereco.Enabled = false;
            txtEstado.Enabled = false;
            txtInscr.Enabled = false;
            txtRazao.Enabled = false;
            txtTelefone.Enabled = false;
            btnAnterior.Enabled = true;
            btnProximo.Enabled = true;
            btnNovo.Enabled = true;
  
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
            btnPesquisar.Enabled = true;
            btnImprimir.Enabled = true;
            btnSair.Enabled = true;
        }

        public void RecebeFornecedores(formInicio.Fornecedor[] fornecedores, int cadFornecedor)
        {
            fornecedor = fornecedores;
            cad = cadFornecedor;
        }

        private void Mostra()
        {
            txtCodigo.Text = fornecedor[atual].codigo.ToString();
            txtNomeFantasia.Text = fornecedor[atual].nomeFantasia;
            txtBairro.Text = fornecedor[atual].bairro;
            txtCep.Text = fornecedor[atual].cep;
            txtCidade.Text = fornecedor[atual].cidade;
            txtCnpj.Text = fornecedor[atual].cnpj;
            txtContato.Text = fornecedor[atual].contato;
            txtEmail.Text = fornecedor[atual].email;
            txtEndereco.Text = fornecedor[atual].endereco;
            txtEstado.Text = fornecedor[atual].estado;
            txtInscr.Text = fornecedor[atual].inscrEstadual;
            txtRazao.Text = fornecedor[atual].razaoSocial;
            txtTelefone.Text = fornecedor[atual].telefone;

        }

        public formFornecedor()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (cad < 100)
            {
                Habilita();
                cadastro = 'N';
                txtCodigo.Text = (cad + 1).ToString();
                txtNomeFantasia.Text = "";
                txtBairro.Text = "";
                txtCep.Text = "";
                txtCidade.Text = "";
                txtCnpj.Text = "";
                txtContato.Text = "";
                txtEmail.Text = "";
                txtEndereco.Text = "";
                txtEstado.Text = "";
                txtInscr.Text = "";
                txtRazao.Text = "";
                txtTelefone.Text = "";
            }
            else
            {
                MessageBox.Show("Banco de dados cheio!!!");
            }
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (atual > 0)
            {
                atual--;
                Mostra();
            }
        }

      

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            Desabilita();
            if (cadastro == 'N')
            {
                fornecedor[cad].codigo = int.Parse(txtCodigo.Text);
                fornecedor[cad].nomeFantasia = txtNomeFantasia.Text;
                fornecedor[cad].bairro = txtBairro.Text;
                fornecedor[cad].cep = txtCep.Text;
                fornecedor[cad].cidade = txtCidade.Text;
                fornecedor[cad].cnpj = txtCnpj.Text;
                fornecedor[cad].contato = txtContato.Text;
                fornecedor[cad].email = txtEmail.Text;
                fornecedor[cad].endereco = txtEndereco.Text;
                fornecedor[cad].estado = txtEstado.Text;
                fornecedor[cad].inscrEstadual = txtInscr.Text;
                fornecedor[cad].razaoSocial = txtRazao.Text;
                fornecedor[cad].telefone = txtTelefone.Text; 


                atual = cad;
                cad++;
            }
            else
            {
                fornecedor[atual].nomeFantasia = txtNomeFantasia.Text;
                fornecedor[atual].bairro = txtBairro.Text;
                fornecedor[atual].cep = txtCep.Text;
                fornecedor[atual].cidade = txtCidade.Text;
                fornecedor[atual].cnpj = txtCnpj.Text;
                fornecedor[atual].contato = txtContato.Text;
                fornecedor[atual].email = txtEmail.Text;
                fornecedor[atual].endereco = txtEndereco.Text;
                fornecedor[atual].estado = txtEstado.Text;
                fornecedor[atual].inscrEstadual = txtInscr.Text;
                fornecedor[atual].razaoSocial = txtRazao.Text;
                fornecedor[atual].telefone = txtTelefone.Text;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            fornecedor[atual].nomeFantasia = "";
            fornecedor[atual].bairro = "";
            fornecedor[atual].cep = "";
            fornecedor[atual].cidade = "";
            fornecedor[atual].cnpj = "";
            fornecedor[atual].contato = "";
            fornecedor[atual].email = "";
            fornecedor[atual].endereco = "";
            fornecedor[atual].estado = "";
            fornecedor[atual].inscrEstadual = "";
            fornecedor[atual].razaoSocial = "";
            fornecedor[atual].telefone = "";
            Mostra();
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (atual < cad - 1)
            {
                atual++;
                Mostra();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnAltera_Click(object sender, EventArgs e)
        {
            Habilita();
            cadastro = 'a';
        }

        private void BtnAnterior_Click_1(object sender, EventArgs e)
        {
            if (atual > 0)
            {
                atual--;
                Mostra();
            }
        }

        private void PanelPesquisa_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnPesquisaPesquisa_Click(object sender, EventArgs e)
        {
            if (txtPesquisa.Text != "")
            {
                int x;
                for (x = 0; x < cad; x++)
                {
                    if (fornecedor[x].nomeFantasia.Contains(txtPesquisa.Text))
                    {
                        break;
                    }
                }
                if (x < cad)
                {
                    atual = x;
                    Mostra();
                }
                else
                {
                    MessageBox.Show("Nome não encontrado!!!");
                }
            }
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = true;
        }

        private void BtnSairPesquisa_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void PanelBotoes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados;
            Graphics objImpressao = e.Graphics;

            strDados = "FICHA DE FORNECEDOR" + (char)10 + (char)10;
            strDados = strDados + "Código" + " " + txtCodigo.Text + (char)10 + (char)10;
            strDados = strDados + "Nome Fantasia" + " " + txtNomeFantasia.Text + (char)10 + (char)10;
            strDados = strDados + "Razão Social" + " " + txtRazao.Text + (char)10 + (char)10;
            strDados = strDados + "Endereço" + " " + txtEndereco.Text + (char)10 + (char)10;
            strDados = strDados + "Bairro" + " " + txtBairro.Text + (char)10 + (char)10;
            strDados = strDados + "Cidade" + " " + txtCidade.Text + (char)10 + (char)10;
            strDados = strDados + "Estado" + " " + txtEstado.Text + (char)10 + (char)10;
            strDados = strDados + "CEP" + " " + txtCep.Text + (char)10 + (char)10;
            strDados = strDados + "Telefone" + " " + txtTelefone.Text + (char)10 + (char)10;
            strDados = strDados + "Contato" + " " + txtContato.Text + (char)10 + (char)10;
            strDados = strDados + "E-Mail" + " " + txtEmail.Text + (char)10 + (char)10;
            strDados = strDados + "CNPJ" + " " + txtCnpj.Text + (char)10 + (char)10;
            strDados = strDados + "Inscr. Estadual" + " " + txtInscr.Text;

            objImpressao.DrawString(strDados, new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 50, 50);
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void txtEstado_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCnpj_TextChanged(object sender, EventArgs e)
        {

        }

        private void formFornecedor_Load(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }
    }
}
