﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPrincipal
{
    public partial class formUsuario : Form
    {
        int atual = 0, cad = 0;
        formInicio.Usuario[] usuario;
        char cadastro;

        public int getCad()
        {
            return cad;
        }

        private void Habilita()
        {
            txtNome.Enabled = true;
            txtLogin.Enabled = true;
            txtSenha.Enabled = true;
            btnAnterior.Enabled = false;
            btnProximo.Enabled = false;
            btnNovo.Enabled = false;
            btnAltera.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            btnPesquisar.Enabled = false;
            btnImprimir.Enabled = false;
            btnSair.Enabled = false;
        }

        private void Desabilita()
        {
            txtNome.Enabled = false;
            txtLogin.Enabled = false;
            txtSenha.Enabled = false;
            btnAnterior.Enabled = true;
            btnProximo.Enabled = true;
            btnNovo.Enabled = true;
            btnAltera.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
            btnPesquisar.Enabled = true;
            btnImprimir.Enabled = true;
            btnSair.Enabled = true;
        }
        public void RecebeUsuarios(formInicio.Usuario[] usuarios, int cadUsuario)
        {
            usuario = usuarios;
            cad = cadUsuario;
        }
        private void Mostra()
        {
            txtCodigo.Text = usuario[atual].codigo.ToString();
            txtNome.Text = usuario[atual].nome;
            txtLogin.Text = usuario[atual].login;
            txtSenha.Text = usuario[atual].senha;
        }
        public formUsuario()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (cad < 100)
            {
                Habilita();
                cadastro = 'N';
                txtCodigo.Text = (cad + 1).ToString();
                txtNome.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
            }
            else
            {
                MessageBox.Show("Banco de dados cheio!!!");
            }
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (atual > 0)
            {
                atual--;
                Mostra();
            }
        }


        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilita();
            if (cadastro == 'N')
            {
                usuario[cad].codigo = int.Parse(txtCodigo.Text);
                usuario[cad].nome = txtNome.Text;
                usuario[cad].login = txtLogin.Text;
                usuario[cad].senha = txtSenha.Text;
                atual = cad;
                cad++;
            }
            else
            {
                usuario[atual].nome = txtNome.Text;
                usuario[atual].login = txtLogin.Text;
                usuario[atual].senha = txtSenha.Text;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            usuario[atual].nome = "";
            usuario[atual].login = "";
            usuario[atual].senha = "";
            Mostra();
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (atual < cad - 1)
            {
                atual++;
                Mostra();
            }
        }

 
        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = true;
        }

        private void BtnAltera_Click(object sender, EventArgs e)
        {
            Habilita();
            cadastro = 'a';
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnPesquisaPesquisa_Click(object sender, EventArgs e)
        {
            if (txtPesquisa.Text != "")
            {
                int x;
                for(x = 0; x < cad; x++)
                {
                    if(usuario[x].nome.Contains(txtPesquisa.Text))
                    {
                        break;
                    }
                }
                if (x < cad)
                {
                    atual = x;
                    Mostra();
                }
                else
                {
                    MessageBox.Show("Nome não encontrado!!!");
                }
            }
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void BtnSairPesquisa_Click(object sender, EventArgs e)
        {
            panelPesquisa.Visible = false;
            txtPesquisa.Text = "";
        }

        private void TxtPesquisa_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string strDados;
            Graphics objImpressao = e.Graphics;

            strDados = "FICHA DE USUÁRIO" + (char)10 + (char)10;
            strDados = strDados + "Código" + " " + txtCodigo.Text + (char)10 + (char)10;
            strDados = strDados + "Nome" + " " + txtNome.Text + (char)10 + (char)10;
            strDados = strDados + "Login" + " " + txtLogin.Text;

            objImpressao.DrawString(strDados, new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 50, 50);
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            Desabilita();
            Mostra();
        }
    }
}
